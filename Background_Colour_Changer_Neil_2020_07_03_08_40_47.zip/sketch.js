var r = 0;
var g = 50;
var b=255;



function setup() {
  createCanvas(1200,400);
}


function draw() {
  background(255);
  
  var mose = ellipse(mouseX, 200, 20, 20)       
  
  
  if (mouseX < 400) {
   background(255,0,0); 
  }

      if (mouseX > 400 & mouseX < 800) {
   background(34,139,34); 
  }
    if (mouseX > 800) {
   background(0, 255, 255); 
  }
  
  
ellipse(mouseX, 200, 20, 20)    
  
}

